# hl7.fhir.fr.example#0.1.0: Exemple d'IG Français

## Pages

* [Accueil](index.md)
* [Téléchargement du guide](downloads.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [Patient français](StructureDefinition-fr-patient.md)

### ImplementationGuides

* [Exemple d'IG Français](index.md)

### Examples

* [frpatient-exemple (Patient)](Patient-frpatient-exemple.md)
