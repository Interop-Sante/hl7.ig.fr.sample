# Accueil - Exemple d'IG Français v0.1.0

* [**Table of Contents**](toc.md)
* **Accueil**

## Accueil

| | |
| :--- | :--- |
| *Official URL*:http://hl7.fr/fhir/fr/example/ImplementationGuide/hl7.fhir.fr.example | *Version*:0.1.0 |
| Draft as of 2026-06-29 | *Computable Name*:ExampleIG |

### Guide d’implémentation d’InteropSanté

Template du guide d’implémentation d’IS

